-- AlterEnum
ALTER TYPE "public"."PaymentMethod" ADD VALUE 'ONLINE';
